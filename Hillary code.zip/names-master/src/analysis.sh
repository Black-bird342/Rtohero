#!/bin/bash

R CMD BATCH analysis.R